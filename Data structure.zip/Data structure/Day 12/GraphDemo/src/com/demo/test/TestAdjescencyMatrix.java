package com.demo.test;

import com.demo.graphs.AdjecencyMatrixdemo;

public class TestAdjescencyMatrix {

	public static void main(String[] args) {
		 AdjecencyMatrixdemo ob=new AdjecencyMatrixdemo(4);
		 ob.addGraph();
		 ob.displayGraph();

	}

}

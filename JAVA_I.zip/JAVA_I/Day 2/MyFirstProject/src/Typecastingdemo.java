
public class Typecastingdemo {

	public static void main(String[] args) {
		int i=34;
		long b=i;  //implicit typecasting
		float f=i;
		byte x=(byte)i;  //explicit type casting
        long l=23l;
        float f1=l;
	}

}

package com.demo.packb;

public class B {
	String nm;

	public B() {
		super();
	}

	public B(String nm) {
		super();
		this.nm = nm;
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	@Override
	public String toString() {
		return "B [nm=" + nm + "]";
	}
	

}

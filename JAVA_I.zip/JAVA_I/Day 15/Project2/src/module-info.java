module Project2{
	requires Project1;
}
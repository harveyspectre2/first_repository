package com.demo.exceptions;

public class InvalidSalaryException extends Exception{
	public InvalidSalaryException(String msg) {
		super(msg);
	}

}
